<?php
//silent is golden